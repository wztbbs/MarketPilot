#!/usr/bin/env python3
"""只在本机临时 MySQL + 模拟服务中验证业务运行恢复；不调用线上、真实模型或交易所。"""
import os
from pathlib import Path
import secrets
import subprocess
import tempfile
import time
import uuid

ROOT = Path(__file__).resolve().parent.parent


def docker(*arguments, env=None):
    return subprocess.run(["docker", *arguments], cwd=ROOT, env=env, check=True,
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()


def main():
    # 编译先于具体测试；不会默认运行全量单元测试。
    subprocess.run(["mvn", "test-compile", "-q"], cwd=ROOT, check=True)
    endpoint = docker("context", "inspect", "--format", "{{.Endpoints.docker.Host}}")
    if not endpoint.startswith("unix://") or os.environ.get("DOCKER_HOST", "").startswith(("tcp:", "ssh:")):
        raise RuntimeError("此脚本只允许本机 Unix socket Docker")
    docker("version", "--format", "{{.Server.Version}}")
    docker("image", "inspect", "mysql:8.0")  # 使用本地镜像，不隐式下载。
    name = "cexpilot-run-contract-" + uuid.uuid4().hex[:10]
    environment = os.environ.copy()
    environment.update(MYSQL_ROOT_PASSWORD=secrets.token_urlsafe(24), MYSQL_DATABASE="cexpilot_run_contract",
                       MYSQL_USER="run_contract", MYSQL_PASSWORD=secrets.token_urlsafe(24))
    artifacts = ROOT / "target/run-contract"
    artifacts.mkdir(parents=True, exist_ok=True)
    configuration = None
    created = False
    try:
        docker("run", "--rm", "--pull=never", "-d", "--name", name, "--label", "cexpilot.test=run-contract",
               "-p", "127.0.0.1::3306", "-e", "MYSQL_ROOT_PASSWORD", "-e", "MYSQL_DATABASE",
               "-e", "MYSQL_USER", "-e", "MYSQL_PASSWORD", "mysql:8.0", "--skip-log-bin", env=environment)
        created = True
        port = docker("port", name, "3306/tcp")
        if not port.startswith("127.0.0.1:"):
            raise RuntimeError("MySQL 必须只绑定本机地址")
        command = ['docker', 'exec', name, 'sh', '-c',
                   'MYSQL_PWD="$MYSQL_PASSWORD" mysql -h 127.0.0.1 -u "$MYSQL_USER" "$MYSQL_DATABASE" -Nse "SELECT 1"']
        deadline = time.monotonic() + 90
        while True:
            ready = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
            if ready.returncode == 0 and ready.stdout.strip() == "1":
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("独立本地 MySQL 未在限时内准备好")
            time.sleep(1)
        descriptor, filename = tempfile.mkstemp(prefix="mysql-", suffix=".properties", dir=artifacts)
        configuration = Path(filename)
        with os.fdopen(descriptor, "w") as output:
            output.write("url=jdbc:mysql://127.0.0.1:" + port.rsplit(":", 1)[1]
                         + "/cexpilot_run_contract?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true\n"
                         + "username=run_contract\npassword=" + environment["MYSQL_PASSWORD"] + "\n")
        print("本地 MySQL 就绪；执行分段运行、强杀 JVM、恢复及业务幂等提交验证。", flush=True)
        subprocess.run(["mvn", "test", "-q", "-Dtest=BusinessRunAdapterTest,BusinessRunMySqlIT",
                        "-Drun.mysql.config=" + str(configuration)], cwd=ROOT, check=True)
        print("本地验证通过。报告：target/surefire-reports/；进程日志：target/run-contract/。", flush=True)
    finally:
        if configuration is not None:
            configuration.unlink(missing_ok=True)
        if created:
            subprocess.run(["docker", "rm", "-f", name], cwd=ROOT, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=False)


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as error:
        print("本地运行契约验证失败：" + str(error), flush=True)
        raise SystemExit(1)
    except subprocess.CalledProcessError as error:
        # 不回显包含凭证的环境或配置，也不打印 docker inspect 的完整输出。
        print("本地运行契约验证失败：" + str(error.cmd[0]) + " 退出码 " + str(error.returncode), flush=True)
        raise SystemExit(1)
