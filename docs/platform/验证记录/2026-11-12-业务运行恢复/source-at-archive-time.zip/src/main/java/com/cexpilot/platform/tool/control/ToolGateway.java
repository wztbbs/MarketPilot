package com.cexpilot.platform.tool.control;

import com.cexpilot.platform.run.*;
import com.cexpilot.platform.tool.*;
import com.cexpilot.platform.execution.QueryBudget;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.stereotype.Component;
import java.time.*;
import java.util.*;
import static com.cexpilot.platform.run.DurableStore.Kind.CALL;

/** 唯一实际调用入口：授权 → 冻结提案 → 确认 → 提交/查单。等待是运行状态，不交给模型修复。 */
@Component
public class ToolGateway implements AutoCloseable {
    private final java.util.concurrent.ThreadPoolExecutor externalCalls=new java.util.concurrent.ThreadPoolExecutor(4,4,30,java.util.concurrent.TimeUnit.SECONDS,new java.util.concurrent.ArrayBlockingQueue<>(32),r->{var t=new Thread(r,"platform-tool-io");t.setDaemon(true);return t;},new java.util.concurrent.ThreadPoolExecutor.AbortPolicy());
    private final ToolRegistry registry;
    private final DurableStore store;
    private final ObjectMapper json;
    private final Clock clock;
    private final List<ToolAccessPolicy> policies;
    private final List<ToolResourceGuard> guards;
    private static final Set<String> TERMINAL = Set.of("SUCCEEDED", "FAILED", "REJECTED", "EXPIRED");
    public ToolGateway(ToolRegistry registry, DurableStore store, ObjectMapper json, Clock clock,
                       List<ToolAccessPolicy> policies, List<ToolResourceGuard> guards) {
        this.registry = registry; this.store = store; this.json = json; this.clock = clock;
        this.policies = List.copyOf(policies); this.guards = List.copyOf(guards);
    }
    public ToolResult invoke(String name, JsonNode arguments, ToolContext context, String position) {
        var definition = registry.definition(name);
        var args = registry.prepareArguments(name, arguments);
        try { authorize(definition, args, context); }
        catch (SecurityException denied) { return new ToolResult(false, null, "工具调用未获授权", "DENIED", null); }
        var scope = RunScope.current();
        if (scope == null) {
            if (definition.control().kind() != ToolControl.Kind.READ || registry.get(name) instanceof AsyncAgentTool)
                return new ToolResult(false, null, "此工具需要可恢复运行入口", "DURABLE_RUN_REQUIRED", null);
            return registry.get(name).execute(args, context);
        }
        scope.checkLease();
        String id = RunScope.invocationId(scope.runId(), position);
        var entry = store.find(CALL, id);
        if (entry == null) {
            checkResources(definition, args, context);
            scope.admitTool();
            var data = json.createObjectNode().put("tool", name).put("contract", registry.contractVersion(name))
                    .put("createdAt", clock.instant().toString()).put("expiresAt", clock.instant().plusSeconds(definition.control().expiresAfterSeconds()).toString())
                    .put("summary", summary(definition, args));
            data.set("arguments", args.deepCopy()); data.set("context", encode(context));
            data.set("resourceVersions", resourceVersions(definition, args));
            data.put("fingerprint", fingerprint(data));
            String state = definition.control().confirmationRequired() ? "CONFIRMATION_REQUIRED" : "READY";
            try { entry = store.create(CALL, id, context.visitorId(), scope.runId(), state, clock.instant(), data); }
            catch (org.springframework.dao.DuplicateKeyException race) { entry = store.require(CALL, id); }
        }
        if (!entry.data().path("tool").asText().equals(name) || !entry.data().path("arguments").equals(args))
            throw new IllegalStateException("恢复位置与冻结调用不一致");
        if ("READY".equals(entry.status())) process(id);
        entry = store.require(CALL, id);
        if (entry.data().has("result")) return json.convertValue(entry.data().get("result"), ToolResult.class);
        throw new RunSuspended(id);
    }
    public DurableStore.Entry confirm(String id, String owner, String fingerprint, boolean approve) {
        for (int attempt = 0; attempt < 8; attempt++) {
            var entry = owned(id, owner); var data = entry.data();
            if(store.require(DurableStore.Kind.RUN,entry.runId()).data().has("result") && "CONFIRMATION_REQUIRED".equals(entry.status()))
                throw new IllegalArgumentException("所属运行已经结束");
            if (!Objects.equals(fingerprint, data.path("fingerprint").asText())) throw new IllegalArgumentException("确认内容指纹不一致");
            if (!"CONFIRMATION_REQUIRED".equals(entry.status())) {
                if (approve && data.path("decision").asText().equals("APPROVED") || !approve && entry.status().equals("REJECTED")) return entry;
                throw new IllegalArgumentException("该调用已不能确认");
            }
            String status;
            if (!clock.instant().isBefore(Instant.parse(data.path("expiresAt").asText()))) {
                status = "EXPIRED"; data.set("result", json.valueToTree(ToolResult.failure("确认已过期")));
            } else {
                if (approve) validateFrozen(entry);
                status = approve ? "READY" : "REJECTED";
                data.put("decision", approve ? "APPROVED" : "REJECTED").put("decidedBy", owner).put("decidedAt", clock.instant().toString());
                if (!approve) data.set("result", json.valueToTree(ToolResult.failure("用户已拒绝该操作")));
            }
            if (store.update(CALL, entry, status, TERMINAL.contains(status) ? null : clock.instant(), null, data)) {
                store.wake(entry.runId(), clock.instant()); return store.require(CALL, id);
            }
        }
        throw new IllegalStateException("调用状态正在变化，请重试");
    }
    public DurableStore.Entry owned(String id, String owner) {
        var entry = store.find(CALL, id);
        if (entry == null || owner == null || !owner.equals(entry.owner())) throw new NoSuchElementException("调用不存在");
        return entry;
    }
    /** 回调只唤醒；结果由受信任的工具适配器查单，外部不能直接伪造成功结果。 */
    public void signal(String id, String jobId) {
        var entry = store.require(CALL, id);
        if (!Objects.equals(entry.data().path("jobId").asText(null), jobId) || jobId == null) throw new SecurityException("异步任务归属不一致");
        if (TERMINAL.contains(entry.status())) return;
        // 不抢占正在提交/轮询的执行者；下一轮到期扫描补偿此竞争。
        if (entry.leaseUntil() == null) store.update(CALL, entry, entry.status(), clock.instant(), null, entry.data());
        store.wake(entry.runId(), clock.instant());
    }
    public void process(String id) {
        var now = clock.instant();
        var entry = store.claim(CALL, id, now, now.plusSeconds(60)); if (entry == null) return;
        var data = entry.data(); String previous = entry.status(); boolean externalStarted=false;
        if (TERMINAL.contains(previous)) return;
        try {
            if (!now.isBefore(Instant.parse(data.path("expiresAt").asText()))) {
                finish(entry, "EXPIRED", ToolResult.failure("调用等待已过期")); return;
            }
            if ("CONFIRMATION_REQUIRED".equals(previous)) {
                store.update(CALL, entry, previous, Instant.parse(data.path("expiresAt").asText()), null, data); return;
            }
            boolean parentEnded=store.require(DurableStore.Kind.RUN,entry.runId()).data().has("result");
            if(parentEnded && Set.of("READY","CONFIRMATION_REQUIRED").contains(previous)) {
                finish(entry,"FAILED",ToolResult.failure("所属运行已经结束，未提交此调用"));return;
            }
            validateFrozen(entry);
            var tool = registry.get(data.path("tool").asText());
            var definition = registry.definition(tool.name());
            var context = decode(data.path("context"), id);
            // 在网络调用之前持久化 EXECUTING。进程在受理和保存之间退出时，可按同一 invocationId 查单。
            if (!store.update(CALL, entry, "EXECUTING", now.plusSeconds(60), now.plusSeconds(60), data)) return;
            var executing=store.require(CALL,id);if(executing.fence()!=entry.fence())return;entry=executing;
            externalStarted=true;
            ToolExecution execution;
            if (tool instanceof AsyncAgentTool async) {
                if (data.hasNonNull("jobId")) execution = remote(()->async.poll(data.path("jobId").asText(), context),data);
                else if (Set.of("EXECUTING", "UNKNOWN").contains(previous)) execution = remote(()->async.recover(data.get("arguments"), context),data);
                else execution = remote(()->async.submit(data.get("arguments"), context),data);
            } else if (Set.of("EXECUTING", "UNKNOWN").contains(previous) && (!definition.control().idempotent() || parentEnded)) {
                execution = ToolExecution.unknown(60000);
            } else {
                ToolResult result = remote(()->tool.execute(data.get("arguments"), context),data);
                if (definition.control().kind() == ToolControl.Kind.OPERATION && Set.of("TIMEOUT", "DEPENDENCY_FAILED", "OUTPUT_INVALID").contains(Objects.toString(result.status(), "")))
                    execution = ToolExecution.unknown(60000);
                else execution = ToolExecution.completed(result);
            }
            entry.data().put("httpRequests",data.path("httpRequests").asInt());
            if (execution.result() != null) {
                if(execution.result().ok())ToolOutputSchema.validateValue(execution.result().data(),definition.outputSchema());
                finish(entry, execution.result().ok() ? "SUCCEEDED" : "FAILED", execution.result());
            } else {
                if (execution.jobId() != null) {
                    if(data.hasNonNull("jobId") && !data.path("jobId").asText().equals(execution.jobId()))throw new IllegalStateException("外部任务身份发生变化");
                    data.put("jobId", execution.jobId());
                }
                store.update(CALL, entry, execution.unknown() ? "UNKNOWN" : "WAITING", clock.instant().plusMillis(execution.pollAfterMs()), null, data);
            }
        } catch (java.util.concurrent.RejectedExecutionException notSubmitted) {
            var current=store.require(CALL,id);
            if(current.fence()==entry.fence())store.update(CALL,current,previous,clock.instant().plusSeconds(5),null,current.data());
        } catch (SecurityException | IllegalArgumentException invalid) {
            var current=store.require(CALL,id);
            if(current.fence()!=entry.fence() || TERMINAL.contains(current.status()))return;
            if(externalStarted)store.update(CALL,current,"UNKNOWN",clock.instant().plusSeconds(60),null,current.data());
            else finish(current, "FAILED", new ToolResult(false, null, "授权、契约或目标资源已变化", "DENIED", null));
        } catch (RuntimeException uncertain) {
            // 外部可能已受理，异常不等于确定失败；保留幂等键并进入查单/补偿。
            var current = store.require(CALL, id);
            if (current.fence() == entry.fence() && !TERMINAL.contains(current.status())) {
                current.data().put("httpRequests",data.path("httpRequests").asInt());
                store.update(CALL, current, "UNKNOWN", clock.instant().plusSeconds(60), null, current.data());
            }
        }
    }
    /** submission/poll 是短调用，长任务必须返回 ACCEPTED；提交超时进入 UNKNOWN。 */
    private <T> T remote(java.util.concurrent.Callable<T> action,ObjectNode data) {
        var collector=new com.cexpilot.platform.observability.NodeTraceCollector.Session();
        var future=externalCalls.submit(()->{
            if(collector!=null)com.cexpilot.platform.observability.NodeTraceCollector.bind(collector);
            try{return action.call();}finally{com.cexpilot.platform.observability.NodeTraceCollector.clear();}
        });
        try{return future.get(30,java.util.concurrent.TimeUnit.SECONDS);}
        catch(InterruptedException interrupted){future.cancel(true);Thread.currentThread().interrupt();throw new IllegalStateException("调用中断，结果待查",interrupted);}
        catch(java.util.concurrent.TimeoutException timeout){future.cancel(true);throw new IllegalStateException("调用超时，结果待查",timeout);}
        catch(java.util.concurrent.ExecutionException failure){throw new IllegalStateException("调用结果待查",failure.getCause());}
        finally {
            var attempts=collector.freezeAndSnapshot();
            data.put("httpRequests",data.path("httpRequests").asInt()+(int)attempts.stream().filter(event->"http_tool_attempt".equals(event.name())).count());
            for(var event:attempts)com.cexpilot.platform.observability.NodeTraceCollector.record(event.name(),event.inputJson(),event.outputJson(),event.durationMs()==null?0:event.durationMs(),event.error());
        }
    }
    @jakarta.annotation.PreDestroy @Override public void close(){externalCalls.shutdownNow();}
    private void finish(DurableStore.Entry entry, String status, ToolResult result) {
        var data = entry.data(); data.set("result", json.valueToTree(result)); data.put("completedAt", clock.instant().toString());
        if (store.update(CALL, entry, status, null, null, data)) store.wake(entry.runId(), clock.instant());
    }
    private void validateFrozen(DurableStore.Entry entry) {
        var data = entry.data(); var definition = registry.definition(data.path("tool").asText());
        if (!data.path("contract").asText().equals(registry.contractVersion(definition.name())) || !data.path("fingerprint").asText().equals(fingerprint(data)))
            throw new SecurityException("调用契约已变更");
        var context = decode(data.get("context"), entry.id());
        authorize(definition, data.get("arguments"), context); checkResources(definition, data.get("arguments"), context);
    }
    private void authorize(ToolDefinition definition, JsonNode args, ToolContext context) {
        if (context == null || context.agentId() == null || !context.allowedTools().contains(definition.name())) throw new SecurityException("Agent 未绑定工具");
        if (definition.control().kind() == ToolControl.Kind.OPERATION && (context.visitorId() == null || context.visitorId().isBlank())) throw new SecurityException("操作缺少可信用户身份");
        for (var policy : policies) policy.check(definition, args, context);
    }
    private void checkResources(ToolDefinition definition, JsonNode args, ToolContext context) {
        var expected = resourceVersions(definition, args); if (expected.isEmpty()) return;
        var matching = guards.stream().filter(g -> g.supports(definition.name())).toList();
        if (matching.size() != 1 || !expected.equals(json.valueToTree(matching.get(0).currentVersions(definition.name(), args, context))))
            throw new SecurityException("目标版本变化或未配置资源校验器");
    }
    private ObjectNode resourceVersions(ToolDefinition definition, JsonNode args) {
        var result = json.createObjectNode();
        for (String pointer : definition.control().resourceVersions()) {
            var value = args.at(pointer); if (value.isMissingNode() || value.isNull() || value.isContainerNode()) throw new IllegalArgumentException("缺少目标资源版本");
            result.set(pointer, value.deepCopy());
        }
        return result;
    }
    private String summary(ToolDefinition definition, JsonNode args) {
        // 摘要来自可信定义；具体值和资源版本在确认卡中另行完整展示，模型不能替换摘要。
        return definition.control().summary();
    }
    private ObjectNode encode(ToolContext c) {
        var data = json.createObjectNode().put("traceId", c.traceId()).put("conversationId", c.conversationId()).put("agentId", c.agentId())
                .put("visitorId", c.visitorId()).put("timezone", c.timezone() == null ? "UTC" : c.timezone().getId())
                .put("requestTime", c.requestTime() == null ? clock.instant().toString() : c.requestTime().toString());
        data.set("allowedTools", json.valueToTree(new TreeSet<>(c.allowedTools()))); return data;
    }
    private ToolContext decode(JsonNode c, String callId) {
        var allowed = new HashSet<String>(); c.path("allowedTools").forEach(n -> allowed.add(n.asText()));
        return new ToolContext(c.path("traceId").asText(), c.path("conversationId").asText(null), ZoneId.of(c.path("timezone").asText()),
                Instant.parse(c.path("requestTime").asText()), c.path("agentId").asText(), c.path("visitorId").asText(null), allowed, callId);
    }
    private String fingerprint(ObjectNode data) {
        var fixed = json.createObjectNode();
        for (String field : List.of("tool", "contract", "arguments", "context", "summary", "resourceVersions", "expiresAt")) fixed.set(field, data.get(field));
        return digest(canonical(fixed).toString());
    }
    private JsonNode canonical(JsonNode node) {
        if (node.isObject()) { var sorted = json.createObjectNode(); var names = new TreeSet<String>(); node.fieldNames().forEachRemaining(names::add); names.forEach(n -> sorted.set(n, canonical(node.get(n)))); return sorted; }
        if (node.isArray()) { var array = json.createArrayNode(); node.forEach(n -> array.add(canonical(n))); return array; }
        return node;
    }
    private static String digest(String value) {
        try { return HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8))); }
        catch (java.security.NoSuchAlgorithmException impossible) { throw new IllegalStateException(impossible); }
    }
}
