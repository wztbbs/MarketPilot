package com.cexpilot.platform.run;

import com.cexpilot.platform.tool.control.ToolGateway;
import jakarta.annotation.PreDestroy;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.time.Clock;
import java.util.Set;
import java.util.concurrent.*;

/** 推拉结合：事件只提前 nextAttempt；到期扫描补偿漏消息、完成未恢复以及进程重启后的过期租约。 */
@Component
public class RunReconciler implements AutoCloseable {
    private final DurableStore store; private final ToolGateway tools; private final RunCoordinator runs; private final Clock clock;
    private final Set<String> local=ConcurrentHashMap.newKeySet();
    private final ThreadPoolExecutor workers=new ThreadPoolExecutor(4,4,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(32),
            r->{var thread=new Thread(r,"platform-resume");thread.setDaemon(true);return thread;},new ThreadPoolExecutor.AbortPolicy());
    public RunReconciler(DurableStore store,ToolGateway tools,RunCoordinator runs,Clock clock) {this.store=store;this.tools=tools;this.runs=runs;this.clock=clock;}
    @Scheduled(fixedDelayString="${platform.run.scan-interval-ms:1000}") public void scan() {
        for(var kind:DurableStore.Kind.values()) for(String id:store.due(kind,clock.instant(),32)) {
            String key=kind+":"+id;if(!local.add(key))continue;
            try { workers.execute(()->{try {if(kind==DurableStore.Kind.CALL)tools.process(id);else runs.drive(id);} finally {local.remove(key);}}); }
            catch(RejectedExecutionException full) {local.remove(key);return;}
        }
    }
    @PreDestroy @Override public void close(){workers.shutdownNow();}
}
