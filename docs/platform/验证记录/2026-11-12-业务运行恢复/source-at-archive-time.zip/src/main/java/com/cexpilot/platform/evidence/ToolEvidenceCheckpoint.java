package com.cexpilot.platform.evidence;

import com.cexpilot.platform.run.RunScope;
import com.cexpilot.platform.agent.AgentRunContext;
import com.cexpilot.platform.tool.ToolResult;
import java.time.Instant;
import java.util.Optional;

/** 重建执行现场时沿用已保存的事实引用，不因暂停恢复再次插入同一份证据。 */
public final class ToolEvidenceCheckpoint {
    private ToolEvidenceCheckpoint() {}
    public static Optional<String> save(ToolEvidenceWriter writer,AgentRunContext run,String agentId,String tool,String position,ToolResult result) {
        if(writer==null || run.session()==null || result.provenance()==null)return Optional.empty();
        var scope=RunScope.current();String key="evidence:"+position;
        if(scope!=null) {var saved=scope.load(key);if(saved!=null)return Optional.ofNullable(saved.path("factId").asText(null));}
        var stored=writer.saveToolEvidence(run.session().conversationId(),run.session().turnId(),run.traceId(),agentId,tool,result.data(),result.provenance(),Instant.now());
        if(scope!=null){var saved=scope.json().createObjectNode();stored.ifPresent(id->saved.put("factId",id));scope.save(key,saved);}
        return stored;
    }
}
