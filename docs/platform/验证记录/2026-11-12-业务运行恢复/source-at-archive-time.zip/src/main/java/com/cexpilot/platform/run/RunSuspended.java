package com.cexpilot.platform.run;

/** 正常控制流：释放当前工作线程，等待调用状态变化；不得转换成模型修复或 ToolResult.failure。 */
public final class RunSuspended extends RuntimeException {
    private final String invocationId;
    public RunSuspended(String invocationId) { super("运行等待工具调用: " + invocationId); this.invocationId = invocationId; }
    public String invocationId() { return invocationId; }
}
