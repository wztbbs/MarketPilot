package com.cexpilot.platform.run;

import com.cexpilot.platform.execution.ExecutionResult;
import java.util.Objects;

/** 一段活跃执行的明确结论；等待不属于业务失败或规划修复。 */
public sealed interface RunStep {
    record Completed(ExecutionResult result) implements RunStep {
        public Completed { Objects.requireNonNull(result); }
    }
    record Waiting(String invocationId) implements RunStep {
        public Waiting {
            if (invocationId == null || invocationId.isBlank()) throw new IllegalArgumentException("等待必须关联持久化调用");
        }
    }
    static Completed completed(ExecutionResult result) { return new Completed(result); }
    static Waiting waiting(String invocationId) { return new Waiting(invocationId); }
}
